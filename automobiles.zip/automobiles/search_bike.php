<html>
<head>
    <title> Transparent Login Form Design </title>
    <link rel="stylesheet" type="text/css" href="search.css">   
</head>
    <body>
    <form action="delete_bike.php" method="POST">
    <div class="container" id="container">
    <div class="login-box">
        <h1>Delete Bike Data</h1>
            <input type="text" name="id" placeholder="Enter Bike Id" required >
            <div class="con">
            <input type="submit" name="delete" value="DELETE">
            </div>
        </div>
        </div>
    </body>
</html>


